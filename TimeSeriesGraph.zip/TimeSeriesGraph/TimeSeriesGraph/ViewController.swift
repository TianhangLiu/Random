//
//  ViewController.swift

//

import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "Time Series Data Graph"
        makeView(width: 1200.0, height: 800.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}   // end of ViewController class


enum DataSeriesType {
    case milk
    case tea
    case coffee
}


class Scene: TScene {
    var headerFont = TFont(fontName: "Helvetica Neue Condensed Black", ofSize: 36.0)
    var font1 = TFont(fontName: "Futura Condensed ExtraBold", ofSize: 16.0)
    var numbersFont = TFont(fontName: "Courier New", ofSize: 16.0)
    var daysFont = TFont(fontName: "Courier New", ofSize: 12.0)
    var Drink = DataSeries(contentsOfFile: "milk-tea-coffee.csv")
    let margins = 150.0
    var graphX = 0.0
    var graphY = 0.0
    var graphWidth = 0.0
    var graphHeight = 0.0
    var graphX2 = 0.0
    var graphY2 = 0.0

    
    override func setup() {
        
        font1.horizontalAlignment = .left
        graphX = margins
        graphY = margins
        graphWidth = tin.width - (margins * 2.0)
        graphHeight = tin.height - (margins * 2.0)
        graphX2 = graphX + graphWidth
        graphY2 = graphY + graphHeight
        // one time setup here
        
    }   // end of the setup function
    
    
    override func update() {
        background(gray: 0.95)
        
        fillColor(gray: 0.85)
        strokeColor(gray: 0.0)
        rect(x: graphX, y: graphY, width: graphWidth, height: graphHeight)
        
        xValueLabels()
        yValueLabels()
        
        fillColor(red: 0.9, green: 0, blue: 0, alpha: 1)
        text(message: "Milk", font: font1, x: graphX, y: graphY - 100.0)
        fillDisable()
        strokeColor(red: 0.9, green: 0, blue: 0, alpha: 1)
        line(x1: graphX + 25.0, y1: graphY - 95.0, x2: graphX + 100.0, y2: graphY - 95.0)
        ellipse(centerX: graphX + 62.5, centerY: graphY - 95.0, width: 5.0, height: 5.0)
        drawLine(valueType: .milk)
        
        fillColor(red: 0.0, green: 0.75, blue: 0, alpha: 1)
        text(message: "Tea", font: font1, x: graphX + 125.0, y: graphY - 100.0)
        fillDisable()
        strokeColor(red: 0.0, green: 0.75, blue: 0, alpha: 1)
        line(x1: graphX + 150, y1: graphY - 95.0, x2: graphX + 225, y2: graphY - 95.0)
        rect(x: graphX + 185.0, y: graphY - 97.5, width: 5, height: 5)
        drawLine(valueType: .tea)
        
        fillColor(red: 0.0, green: 0, blue: 0.9, alpha: 1)
        text(message: "Coffee", font: font1, x: graphX + 250.0, y: graphY - 100.0)
        fillDisable()
        strokeColor(red: 0.0, green: 0, blue: 0.9, alpha: 1)
        line(x1: graphX + 275.0, y1: graphY - 95.0, x2: graphX + 350.0, y2: graphY - 95.0)
        triangle(x1: graphX + 310.0, y1: graphY - 97.5, x2: graphX + 315, y2: graphY - 97.5, x3: graphX + 312.5, y3: graphY - 92.5)
        drawLine(valueType: .coffee)
        
        drawTitle()
        drawLabel()
        view?.stopUpdates()

        
        // drawing goes here
        
    }   // end of the update function
    func drawLine(valueType: DataSeriesType) {
        var px = 0.0
        var py = 0.0
        var index = 0
        
        lineWidth(1)
        
        for point in Drink.data {
            let x = remap(value: Double(index), start1: 0, stop1: 94, start2: graphX + 5.0, stop2: graphX2 - 5.0)
            let y: Double
            
            switch valueType {
            case .milk:
                y = remap(value: Double(point.milk), start1: 5.0, stop1: 50.0, start2: graphY, stop2: graphY2)
                ellipse(centerX: x, centerY: y, width: 5.0, height: 5.0)
            case .tea:
                y = remap(value: Double(point.tea), start1: 5.0, stop1: 50.0, start2: graphY, stop2: graphY2)
                rect(x: x-2.5, y: y-2.5, width: 5.0, height: 5.0)
            case .coffee:
                y = remap(value: Double(point.coffee), start1: 5.0, stop1: 50.0, start2: graphY, stop2: graphY2)
                triangle(x1: x-2.5, y1: y-2.5, x2: x+2.5, y2: y-2.5, x3: x, y3: y+2.5)
            }
            
            if index > 0 {
                line(x1: px, y1: py, x2: x, y2: y)
            }
            
            
            
            px = x
            py = y
            index += 1
        }
    }
    
    
    func yValueLabels() {
        lineWidth(1)
        numbersFont.horizontalAlignment = .right
        numbersFont.verticalAlignment = .center
        for vy in stride(from: 0, to: 51, by: 5) {
            
            strokeColor(gray: 0.75)
            let y = remap(value: Double(vy), start1: 0.0, stop1: 50.0, start2: graphY, stop2: graphY2)
            line(x1: graphX, y1: y, x2: graphX2, y2: y)
            
            fillColor(gray: 0.01)
            strokeDisable()
            text(message: "\(vy)", font: numbersFont, x: graphX - 5.0, y: y)
            
        }
        
    }
    
    
    func xValueLabels() {
        lineWidth(1)
        daysFont.horizontalAlignment = .center
        daysFont.verticalAlignment = .top
        // every 30 days? This isn't very good.
        for vx in stride(from: 0, to: 95, by: 10) {
            
            strokeColor(gray: 0.75)
            let x = remap(value: Double(vx), start1: 0, stop1: 95, start2: graphX + 5.0, stop2: graphX2 - 5.0)
            line(x1: x, y1: graphY, x2: x, y2: graphY2)
            
            fillColor(gray: 0.01)
            strokeDisable()
            
            let day = Drink.data[vx]
            text(message: "\(day.year)", font: daysFont, x: x, y: graphY - 5.0)
            
        }
        
    }
    
    
    func drawTitle() {
        // Header
        fillColor(gray: 0.01)
        headerFont.horizontalAlignment = .center
        text(message: "Milk / Tea / Coffee", font: headerFont, x: tin.midX, y: tin.height - 80.0)
    }
    
    func drawLabel() {
        fillColor(gray: 0.01)
        font1.horizontalAlignment = .center
        
        pushState()
        font1.horizontalAlignment = .center
        translate(dx: graphX - (margins/2), dy: tin.midY)
        rotate(by: Double.pi/2)
        text(message: "Gallons consumed per capita", font: font1, x: 0, y: 0)
        popState()
        text(message: "Year", font: font1, x: tin.midX, y: graphY - 80.0)
    }
    
}   // end of Scene class

